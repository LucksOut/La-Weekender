#!/usr/bin/env python3
"""Daily LA Weekender importer: Ticketmaster Discovery API and configured public iCalendar feeds."""
import json, os, re, sys, hashlib, urllib.parse, urllib.request
from datetime import datetime, timedelta, timezone, date
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'events.json'
TZ = ZoneInfo('America/Los_Angeles')
TODAY = datetime.now(TZ).date()
HEADERS = {'User-Agent':'LAWeekender/1.0 (event listing aggregation; source links retained)', 'Accept':'application/json, text/calendar'}

def get(url):
    req=urllib.request.Request(url, headers=HEADERS)
    with urllib.request.urlopen(req, timeout=25) as resp:
        return resp.read()

def clean(s): return re.sub(r'\s+', ' ', str(s or '')).strip()
def key(ev):
    title = re.sub(r'[^a-z0-9]+','',clean(ev.get('title')).lower())
    where = re.sub(r'[^a-z0-9]+','',clean(ev.get('where')).lower())
    return (title, ev.get('start',''), where)
def is_expired(ev):
    end=ev.get('end') or ev.get('start')
    if not end: return False
    try: return date.fromisoformat(end) < TODAY
    except ValueError: return True

def tm_events(api_key):
    """Fetch all pages up to 500 results, within 90 days and 65-mile LA radius."""
    out=[]
    start=datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
    end=(datetime.now(timezone.utc)+timedelta(days=90)).strftime('%Y-%m-%dT%H:%M:%SZ')
    for page in range(5):
        params={'apikey':api_key,'latlong':'34.0522,-118.2437','radius':65,'unit':'miles','size':100,'page':page,'sort':'date,asc','startDateTime':start,'endDateTime':end}
        url='https://app.ticketmaster.com/discovery/v2/events.json?'+urllib.parse.urlencode(params)
        obj=json.loads(get(url))
        items=obj.get('_embedded',{}).get('events',[])
        for item in items:
            if item.get('test') or item.get('dates',{}).get('status',{}).get('code') in ('cancelled','canceled','postponed'): continue
            start_date=item.get('dates',{}).get('start',{}).get('localDate')
            if not start_date: continue
            venues=item.get('_embedded',{}).get('venues',[])
            venue=venues[0] if venues else {}
            city=venue.get('city',{}).get('name','')
            state=venue.get('state',{}).get('stateCode','')
            if state and state != 'CA': continue
            classifications=item.get('classifications',[])
            segment=classifications[0].get('segment',{}).get('name','') if classifications else ''
            genre=classifications[0].get('genre',{}).get('name','') if classifications else ''
            cat='parks' if segment in ('Arts & Theatre',) and 'Family' in genre else 'music'
            price_ranges=item.get('priceRanges',[])
            price=('From $'+str(round(price_ranges[0]['min'],2))) if price_ranges and price_ranges[0].get('min') is not None else ''
            out.append({'title':clean(item.get('name')),'start':start_date,'end':'','when':clean(item.get('dates',{}).get('start',{}).get('localTime','')),'where':clean(venue.get('name') or city),'city':clean(city),'cat':cat,'days':[],'free':False,'price':price,'blurb':clean(genre or segment),'url':item.get('url',''),'source':'Ticketmaster','source_id':'tm:'+item.get('id','')})
        if not items or page >= obj.get('page',{}).get('totalPages',1)-1: break
    return out

def unfold(text):
    return re.sub(r'\r?\n[ \t]', '', text)

def ical_events(url):
    """Parse VEVENTs with explicit DTSTART dates. Recurring RRULE events are skipped to avoid false dates."""
    raw=unfold(get(url).decode('utf-8-sig','replace'))
    out=[]
    for block in re.findall(r'BEGIN:VEVENT\s*(.*?)\s*END:VEVENT',raw,re.S):
        fields={}
        for line in block.splitlines():
            if ':' not in line: continue
            name,value=line.split(':',1)
            fields[name.split(';')[0].upper()]=value.replace('\\n',' ').replace('\\,',',').replace('\\;',';')
        if 'RRULE' in fields or fields.get('STATUS','').upper()=='CANCELLED': continue
        rawdate=fields.get('DTSTART','')
        match=re.match(r'^(\d{4})(\d{2})(\d{2})',rawdate)
        if not match: continue
        start='-'.join(match.groups())
        if date.fromisoformat(start) < TODAY or date.fromisoformat(start)>TODAY+timedelta(days=120): continue
        title=clean(fields.get('SUMMARY'))
        if not title: continue
        desc=clean(fields.get('DESCRIPTION'))[:230]
        location=clean(fields.get('LOCATION'))
        link=fields.get('URL','')
        if not link.startswith('https://'): link=url if url.startswith('https://') else ''
        out.append({'title':title,'start':start,'end':'','when':start,'where':location,'city':'','cat':'music','days':[],'free':False,'price':'','blurb':desc,'url':link,'source':'iCalendar','source_id':'ics:'+hashlib.sha256((url+fields.get('UID',title+start)).encode()).hexdigest()[:24]})
    return out

def main():
    data=json.loads(DATA.read_text())
    existing=data.get('events',[])
    sources=[]; failures=[]; fresh=[]
    api=os.getenv('TICKETMASTER_API_KEY','').strip()
    if api:
        try:
            result=tm_events(api); fresh.extend(result); sources.append(f'Ticketmaster: {len(result)}')
        except Exception as exc: failures.append('Ticketmaster: '+str(exc))
    else: print('Ticketmaster not configured: set TICKETMASTER_API_KEY')
    urls=[s.strip() for s in os.getenv('ICAL_FEED_URLS','').splitlines() if s.strip()]
    for url in urls:
        if not url.startswith('https://'):
            failures.append('Invalid iCalendar URL (HTTPS required)'); continue
        try:
            result=ical_events(url); fresh.extend(result); sources.append(f'iCalendar: {len(result)}')
        except Exception as exc: failures.append('iCalendar: '+str(exc))
    if failures: print('\n'.join(failures),file=sys.stderr)
    if not api and not urls:
        print('No discovery sources configured. Existing listings will be retained; no false refresh stamp.')
        return 0
    if failures and not sources:
        print('All sources failed. Retaining last published events.',file=sys.stderr)
        return 1
    merged={}
    for ev in existing:
        if not is_expired(ev): merged[key(ev)]=ev
    for ev in fresh:
        if not is_expired(ev) and ev.get('title') and ev.get('start'):
            merged[key(ev)]=ev
    result=sorted(merged.values(),key=lambda x:(not bool(x.get('start')),x.get('start') or '9999',x.get('title','')))
    data['events']=result
    data['meta']['updated']=datetime.now(TZ).strftime('%b %-d, %Y %I:%M %p PT')
    data['meta']['note']='Updated from configured event sources. Verify prices and details with organizers before visiting.'
    data['meta']['sources']=sources
    data['meta']['source_errors']=failures
    DATA.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
    print(f'Published {len(result)} listings; discovered {len(fresh)}; sources: {sources}; failures: {len(failures)}')
    return 0

if __name__=='__main__': sys.exit(main())
